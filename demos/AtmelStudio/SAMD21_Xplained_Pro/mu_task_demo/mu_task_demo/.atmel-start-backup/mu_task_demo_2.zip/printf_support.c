#include "printf_support.h"
#include "mu_port.h"

// ================
// support for printf()

int _write(int file, char *ptr, int len) {
  // void file;
  int n = len;

  while (n-- > 0) {
    while (!mu_port_serial_can_write())
  		;
    mu_port_serial_write(*ptr++);
  }
  return len;
}

int _read(int file, char *ptr, int len) {
  // void file;
  int n = len;

  while (n-- > 0) {
    while (!mu_port_serial_can_read())
			;
    *ptr++ = mu_port_serial_read();
  }
  return len;
}
