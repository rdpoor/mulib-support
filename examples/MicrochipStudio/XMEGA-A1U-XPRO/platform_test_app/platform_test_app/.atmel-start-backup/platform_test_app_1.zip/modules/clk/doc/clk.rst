
==========
CLK driver
==========
The clock sources are divided in two main groups: internal oscillators and external clock sources. Most of the clock
sources can be directly enabled and disabled from software, while others are automatically enabled or disabled,
depending on peripheral settings. After reset, the device starts up running from the 2MHz internal oscillator. The other
clock sources, DFLLs and PLL, are turned off by default

Features
--------
* Initialization

Applications
------------
* N/A

Dependencies
------------
* N/A 

Concurrency
-----------
N/A

Limitations
-----------
N/A

Knows issues and workarounds
----------------------------
N/A

